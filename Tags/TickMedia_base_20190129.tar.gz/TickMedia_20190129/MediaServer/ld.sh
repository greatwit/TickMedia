#!/bin/bash
export LD_LIBRARY_PATH=../common/ffmpeg/lib
